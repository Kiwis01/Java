import java.text.NumberFormat;
import java.util.Locale;

public class Graduate extends Student{
	//Variable for the graduation fee
	private double gradFee;
	
	//Constructor that inherits all the data from the student and adds the graduation fee
	public Graduate(String fName, String lName, String id, int credits, double rate, double gradFee) {
		super(fName, lName, id, credits, rate);
		this.gradFee = gradFee;
	}
	
	//method that calculates the tuition if the student is a graduate
	public void computeTuition() {
		tuition = (rate * numCredit + gradFee);
	}
	
	//method that inherits the info from the student class and adds the grad fee in the correct currency format
	public String toString() {
		NumberFormat f = NumberFormat.getCurrencyInstance(Locale.US);
		String formatG = "";
		formatG = 	"\nGraduate Student:" + 
					super.toString() +
					"Grad Fee:\t\t" + 
					f.format(gradFee) + "\n" + "\n";
		return formatG;
	}
	
}

