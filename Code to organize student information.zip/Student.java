import java.text.NumberFormat;
import java.util.Locale;

public abstract class Student {
	//Initializing all the protected variables
	protected String firstName;
	protected String lastName;
	protected String studentID;
	protected int numCredit;
	protected double rate;
	protected double tuition;
	
	//Constructor that stores all the parameters
	public Student (String fName, String lName, String id, int credits, double rate) {
		firstName = fName;
		lastName = lName;
		studentID = id;
		numCredit = credits;
		this.rate = rate;
		tuition = 0.0;
	}
	
	//method that will return the number of credits of the student
	public int getNumCredit() {
		return numCredit;
	}
	
	//method that calls the calculation of the tution cost
	public abstract void computeTuition();
	
	//Method that formats the text and the prices by using the number format.
	public String toString() {
		NumberFormat f = NumberFormat.getCurrencyInstance(Locale.US);
		String format = "";
		format = "\nFirst name:\t\t" + firstName +
				 "\nLast name:\t\t" + lastName +
				 "\nStudent ID:\t\t" + studentID + 
				 "\nCredits:\t\t" + numCredit + 
				 "\nRate:\t\t\t" + f.format(rate) +
				 "\nTuition:\t\t" + f.format(tuition) + "\n";		
		return format;
	}
	
	
}




