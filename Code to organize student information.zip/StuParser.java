
public class StuParser {
	public static Student parseStringToStudent(String lineToParse) {
		
		//Initialing an array type String, and filled it up by splitting the input from the student
		String[] spl = lineToParse.split("/");
		
		//If statement that creates an object of the student graduate type if the user input was graduate
		if (spl[0].equalsIgnoreCase("Graduate")) {
			Student g = new Graduate(spl[1], spl[2], spl[3], Integer.parseInt(spl[4]), Double.parseDouble(spl[5]), Double.parseDouble(spl[6]));
			return g;
		}
		
		//If statement that creates an object of the student UnderGrad type if the user input was UnderGrad
		else if(spl[0].equalsIgnoreCase("UnderGrad")) {
			
			//If statements that will state the boolean for inState true or false, depending on what the student input was
			if(spl[6].equalsIgnoreCase("InState")) {
			Student ui = new UnderGrad(spl[1], spl[2], spl[3], Integer.parseInt(spl[4]), Double.parseDouble(spl[5]), true, Double.parseDouble(spl[7]));
			return ui;
			}	
			else if(spl[6].equalsIgnoreCase("OutState")) {
			Student uo = new UnderGrad(spl[1], spl[2], spl[3], Integer.parseInt(spl[4]), Double.parseDouble(spl[5]), false, Double.parseDouble(spl[7]));
			return uo;
			}
		}
		
		return null;
	}
}
