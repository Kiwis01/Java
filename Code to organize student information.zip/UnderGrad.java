import java.text.NumberFormat;
import java.util.Locale;

public class UnderGrad extends Student {
	//Three variables initialized
	private boolean inState = true;
	private int creditUpperbound;
	private double programFee;
	
	//Constructor that inherits all the data from the student class and adds a boolean and another double
	public UnderGrad(String fName, String lName, String id, int credits, double rate, boolean inState, double programFee) {
		super(fName, lName, id, credits, rate);
		this.inState = inState;
		this.programFee = programFee;
		
		//Statements that will determine what will be the credit Upper bound depending on wether the student is out or in state
		if (inState == true) {
			creditUpperbound = 7;
		}
		
		else if(inState == false) {
			creditUpperbound = 12;
		}
	}
	
	//Method that computes the tuition cost for undergraduate students, depending on whether they are in or out state.
	public void computeTuition() {
		if(numCredit >= creditUpperbound) {
			tuition = rate * creditUpperbound + programFee;
		}
		else{
			tuition = rate * numCredit + programFee;
		}
	}
	
	//Method that inherits the data from student and adds the program fee with the correct currency, and prints out or in state depending on where the student is from
	public String toString() {
		NumberFormat f = NumberFormat.getCurrencyInstance(Locale.US);
		if(inState == true) {
		String format = " ";
		format =	"\nUnderGrad:" + 
					"\nIn-State" + 
			//		
			 "\nFirst name:\t\t" + firstName + 
			 "\nLast name:\t\t" + lastName + 
			 "\nStudent ID:\t\t" + studentID + 
			 "\nCredits:\t\t" + numCredit + 
			 "\nRate:\t\t\t" + f.format(rate) +
			 "\nTuition:\t\t" + f.format(tuition) + "\n" +
			 //super.toString() + 
			"Student Program Fee:\t" + f.format(programFee) + "\n";
					return format;
		}
		
		else {
		String format = " ";
		format =	"\nUnderGrad:" + 
					"\nOut-Of-State" + 
		//			 super.toString() + 
					
 "\nFirst name:\t\t" + firstName + 
 "\nLast name:\t\t" + lastName + 
 "\nStudent ID:\t\t" + studentID + 
 "\nCredits:\t\t" + numCredit + 
 "\nRate:\t\t\t" + f.format(rate) +
 "\nTuition:\t\t" + f.format(tuition) + "\n"
 +
					"Student Program Fee:\t" + f.format(programFee) + "\n";
					return format;
		}		
	}
	
}
