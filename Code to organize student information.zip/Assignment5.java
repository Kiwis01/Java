//  Description: The Assignment 5 class displays a menu of choices to a user
//               and performs the chosen task. It will keep asking a user to
//               enter the next choice until the choice of 'Q' (Quit) is
//               entered.

import java.io.*;         //to use InputStreamReader and BufferedReader
import java.util.*;       //to use ArrayList

public class Assignment5
 {
  public static void main (String[] args)
   {
     char input1;
     String inputInfo = new String();
     String line = new String();
     boolean operation;

     // ArrayList object is used to store student objects
     ArrayList<Student> studentList = new ArrayList<Student>();

     try
      {
       printMenu();     // print out menu

       // create a BufferedReader object to read input from a keyboard
       InputStreamReader isr = new InputStreamReader (System.in);
       BufferedReader stdin = new BufferedReader (isr);

       do
        {
         System.out.println("What action would you like to perform?");
         line = stdin.readLine().trim();
         input1 = line.charAt(0);
         input1 = Character.toUpperCase(input1);

         if (line.length() == 1)
          {
           switch (input1)
            {
             case 'A':   //Add Student
               System.out.print("Please enter a student information to add:\n");
               inputInfo = stdin.readLine().trim();
                
               Student st = StuParser.parseStringToStudent(inputInfo);
               studentList.add(st);
               
               
               break;
             case 'C':   //Compute tuition
                
                //For loop that will go through all the students and compute each tuition.
            	 for(int i = 0; i < studentList.size(); i++) {
                	studentList.get(i).computeTuition();
                }
                
                System.out.print("tuition computed\n");
               break;
             case 'D':   //Count certain students
               System.out.print("Please enter a number of credits:\n");
               inputInfo = stdin.readLine().trim();
               int credits = Integer.parseInt(inputInfo);
               int count =0;
                
             //For loop that iterates through all the students and will count them if they have the same number of credits as inputed.
               for(int i = 0; i < studentList.size(); i++) {
            	   if(studentList.get(i).getNumCredit() == credits) {
            		   count = count + 1;
            	   }
               }
               
              System.out.println("The number of students who are taking " + credits
                                   + " credits is: " + count + "\n"); 
               break;
             case 'L':   //List Students
                
            	//Variable that will store the Students to print later on
            	 String lis = "";
            	
            	 //If statement that will print there are no students if there is no student
            	 if(studentList.size() == 0) {
              		lis = "no student\n";  
              	 }
            	 
            	 //else statement that will add all the students to the variable lis
            	else{
              		  for(int i = 0; i < studentList.size(); i++) {
              			  lis = lis + studentList.get(i);
              		  }
              	 	}
            	 //Print the string lis
            	 System.out.println(lis);
               break;
             case 'Q':   //Quit
               break;
             case '?':   //Display Menu
               printMenu();
               break;
             default:
               System.out.print("Unknown action\n");
               break;
            }
         }
        else
         {
           System.out.print("Unknown action\n");
          }
        } while (input1 != 'Q'); // stop the loop when Q is read
      }
     catch (IOException exception)
      {
        System.out.println("IO Exception");
      }
  }

   /** The method printMenu displays the menu to a user **/
   public static void printMenu()
   {
     System.out.print("Choice\t\tAction\n" +
                      "------\t\t------\n" +
                      "A\t\tAdd Student\n" +
                      "C\t\tCompute Tuition\n" +
                      "D\t\tCount Certain Students\n" +
                      "L\t\tList Students\n" +
                      "Q\t\tQuit\n" +
                      "?\t\tDisplay Help\n\n");
     }

  }//end of class


